class Skillset < ApplicationRecord
  belongs_to :skill
  belongs_to :developer
end
