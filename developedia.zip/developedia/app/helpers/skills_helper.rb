module SkillsHelper
end
