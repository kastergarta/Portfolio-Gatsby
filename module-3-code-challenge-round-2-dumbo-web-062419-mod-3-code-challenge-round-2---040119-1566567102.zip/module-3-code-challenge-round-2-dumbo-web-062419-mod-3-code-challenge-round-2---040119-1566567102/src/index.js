document.addEventListener("DOMContentLoaded", function(){
  fetch(`http://localhost:3000/beers`)
  .then(resp => resp.json())
  .then(renderAllBeer)
})
// +++++++++++++++ VAR's++++++++++++++++++++
const ul = document.getElementById("list-group")
const div = document.getElementById("beer-detail")
// +++++++++++++++++++++++++++++++++++

function renderAllBeer (data){
  data.forEach (renderListBeer)
}

function renderListBeer (beer){
ul.innerHTML +=
`
<li class="list-group-item" id="${beer.id}">${beer.name}</li>
`
}
// ++++++++++++ SHOW SINGLE BEER +++++++++++++++++++++++
function fetchSingleBeer (event){
  beerId = event.target.id

  fetch(`http://localhost:3000/beers/${beerId}`)
  .then(resp => resp.json())
  .then(showBeer)

}

function showBeer (beer){
  div.innerHTML =
  `
  <h1>${beer.name}</h1>
  <img src="${beer.image_url}">
  <h3>${beer.tagline}</h3>
  <textarea id="text-${beer.id}">${beer.description}</textarea>
  <button id="edit-beer-${beer.id}" class="btn btn-info"> Save </button>
  `
}
// ++++++++++++ EDIT (PATCH REQUEST)+++++++++++++++++++++++

function fetchPatch (event){

beerId = event.target.id.split("-")[2]

const textArea = document.querySelector("textarea")

console.log(typeof event.target.className)
if (event.target.className === ("btn btn-info")) {

fetch(`http://localhost:3000/beers/${beerId}`,{
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json'},
    body: JSON.stringify({ description: textArea.value })
  })

    .then(resp => resp.json())
    .then(console.log)
    }
}
// +++++++++++ LISTENERS ++++++++++++++++++++++++

ul.addEventListener('click', fetchSingleBeer)
div.addEventListener('click', fetchPatch)
